// Previous interfaces remain...

export type PlayerTier = 'A' | 'B';
export type BowlerType = 'Spin' | 'Fast';

export interface PlayerAttributes {
  battingAverage?: number;
  strikeRate?: number;
  centuries?: number;
  economyRate?: number;
  wickets?: number;
  bestBowling?: string;
  dismissals?: number; // For wicket keepers
}

export interface Player {
  id: string;
  name: string;
  role: 'Batsman' | 'Bowler' | 'All-rounder' | 'Wicket Keeper';
  tier: PlayerTier;
  bowlerType?: BowlerType;
  batting: number;
  bowling: number;
  fielding: number;
  experience: number;
  form: number;
  age: number;
  battingStyle?: 'Attacking' | 'Defensive' | 'Normal' | 'Situational';
  attributes: PlayerAttributes;
  basePrice: number;
  contractYears: number;
  available: boolean;
  leadership?: number;
}

export interface AuctionPool {
  batsmen: {
    tierA: Player[];
    tierB: Player[];
  };
  spinBowlers: {
    tierA: Player[];
    tierB: Player[];
  };
  fastBowlers: {
    tierA: Player[];
    tierB: Player[];
  };
  allRounders: {
    tierA: Player[];
    tierB: Player[];
  };
  wicketKeepers: {
    tierA: Player[];
    tierB: Player[];
  };
}

// Rest of the types remain...