import { 
  Player, 
  PlayerRole, 
  BattingStyle, 
  PlayerTier,
  BowlerType,
  PlayerAttributes
} from '../types/game';
import { v4 as uuidv4 } from 'uuid';

const FIRST_NAMES = ['John', 'David', 'Michael', 'James', 'Robert', 'William', 'Richard', 'Joseph', 'Thomas', 'Christopher'];
const LAST_NAMES = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez'];
const BATTING_STYLES: BattingStyle[] = ['Attacking', 'Defensive', 'Normal', 'Situational'];

const randomInt = (min: number, max: number) => {
  return Math.floor(Math.random() * (max - min + 1)) + min;
};

const randomElement = <T>(array: T[]): T => {
  return array[Math.floor(Math.random() * array.length)];
};

const generateAttributes = (role: PlayerRole, tier: PlayerTier): PlayerAttributes => {
  switch (role) {
    case 'Batsman':
      return tier === 'A' ? {
        strikeRate: randomInt(150, 180),
        battingAverage: randomInt(50, 65),
        centuries: randomInt(5, 10)
      } : {
        strikeRate: randomInt(130, 150),
        battingAverage: randomInt(35, 50),
        centuries: randomInt(2, 4)
      };

    case 'Bowler':
      return tier === 'A' ? {
        economyRate: randomInt(40, 60) / 10, // 4.0-6.0
        wickets: randomInt(50, 80),
        bestBowling: `${randomInt(4, 6)}-${randomInt(10, 20)}`
      } : {
        economyRate: randomInt(60, 70) / 10, // 6.0-7.0
        wickets: randomInt(30, 50),
        bestBowling: `${randomInt(3, 4)}-${randomInt(20, 30)}`
      };

    case 'All-rounder':
      return tier === 'A' ? {
        strikeRate: randomInt(140, 160),
        economyRate: randomInt(50, 60) / 10,
        battingAverage: randomInt(35, 45),
        wickets: randomInt(30, 50)
      } : {
        strikeRate: randomInt(120, 140),
        economyRate: randomInt(60, 70) / 10,
        battingAverage: randomInt(25, 35),
        wickets: randomInt(20, 30)
      };

    case 'Wicket Keeper':
      return tier === 'A' ? {
        dismissals: randomInt(20, 30),
        strikeRate: randomInt(130, 150),
        battingAverage: randomInt(35, 45)
      } : {
        dismissals: randomInt(10, 20),
        strikeRate: randomInt(110, 130),
        battingAverage: randomInt(25, 35)
      };
  }
};

const generatePlayerStats = (role: PlayerRole, tier: PlayerTier) => {
  const baseStat = tier === 'A' ? 10 : 0;
  
  switch (role) {
    case 'Batsman':
      return {
        batting: randomInt(60 + baseStat, 85 + baseStat),
        bowling: randomInt(10, 30),
        fielding: randomInt(60, 80),
        leadership: randomInt(40, 90),
      };
    case 'Bowler':
      return {
        batting: randomInt(20, 40),
        bowling: randomInt(65 + baseStat, 90 + baseStat),
        fielding: randomInt(60, 80),
        leadership: randomInt(40, 90),
      };
    case 'All-rounder':
      return {
        batting: randomInt(50 + baseStat, 75 + baseStat),
        bowling: randomInt(50 + baseStat, 75 + baseStat),
        fielding: randomInt(65, 85),
        leadership: randomInt(50, 90),
      };
    case 'Wicket Keeper':
      return {
        batting: randomInt(55 + baseStat, 80 + baseStat),
        bowling: randomInt(0, 20),
        fielding: randomInt(75, 90),
        leadership: randomInt(60, 95),
      };
  }
};

export const generatePlayer = (
  role: PlayerRole, 
  tier: PlayerTier, 
  bowlerType?: BowlerType
): Player => {
  const stats = generatePlayerStats(role, tier);
  const attributes = generateAttributes(role, tier);
  const basePrice = tier === 'A' 
    ? randomInt(150000, 300000)
    : randomInt(50000, 150000);
  
  return {
    id: uuidv4(),
    name: `${randomElement(FIRST_NAMES)} ${randomElement(LAST_NAMES)}`,
    role,
    tier,
    bowlerType,
    battingStyle: randomElement(BATTING_STYLES),
    age: randomInt(19, 35),
    experience: randomInt(100, 500),
    form: randomInt(60, 90),
    basePrice,
    contractYears: randomInt(1, 3),
    available: true,
    attributes,
    ...stats,
  };
};

export const generateBalancedPlayerPool = () => {
  const pool = {
    batsmen: {
      tierA: Array.from({ length: 5 }, () => generatePlayer('Batsman', 'A')),
      tierB: Array.from({ length: 10 }, () => generatePlayer('Batsman', 'B'))
    },
    spinBowlers: {
      tierA: Array.from({ length: 2 }, () => generatePlayer('Bowler', 'A', 'Spin')),
      tierB: Array.from({ length: 2 }, () => generatePlayer('Bowler', 'B', 'Spin'))
    },
    fastBowlers: {
      tierA: Array.from({ length: 1 }, () => generatePlayer('Bowler', 'A', 'Fast')),
      tierB: Array.from({ length: 1 }, () => generatePlayer('Bowler', 'B', 'Fast'))
    },
    allRounders: {
      tierA: Array.from({ length: 2 }, () => generatePlayer('All-rounder', 'A')),
      tierB: Array.from({ length: 4 }, () => generatePlayer('All-rounder', 'B'))
    },
    wicketKeepers: {
      tierA: Array.from({ length: 1 }, () => generatePlayer('Wicket Keeper', 'A')),
      tierB: Array.from({ length: 1 }, () => generatePlayer('Wicket Keeper', 'B'))
    }
  };

  return pool;
};

export const generateNewSeasonPlayers = (count: number = 2): Player[] => {
  return Array.from({ length: count }, () => 
    generatePlayer(
      randomElement(['Batsman', 'Bowler', 'All-rounder', 'Wicket Keeper']),
      randomElement(['A', 'B'])
    )
  );
};