import { Team, Player, TeamCompositionRules, PlayerTier } from '../types/game';

export const DEFAULT_TEAM_RULES: TeamCompositionRules = {
  minWicketKeepers: 2,
  minBowlers: 6,
  minBatsmen: 4,
  minAllRounders: 2,
  maxTierABatsmen: 2,
  maxTierBBatsmen: 3,
  maxTierABowlers: 2,
  maxTierBBowlers: 2,
  maxTierAAllRounders: 1,
  maxTierBAllRounders: 1,
  maxTierAWicketKeepers: 1,
  maxTierBWicketKeepers: 1
};

export function validateTeamComposition(
  players: Player[],
  rules: TeamCompositionRules = DEFAULT_TEAM_RULES
): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Count players by role and tier
  const wicketKeepers = groupPlayersByTier(players.filter(p => p.role === 'Wicket Keeper'));
  const bowlers = groupPlayersByTier(players.filter(p => p.role === 'Bowler'));
  const batsmen = groupPlayersByTier(players.filter(p => p.role === 'Batsman'));
  const allRounders = groupPlayersByTier(players.filter(p => p.role === 'All-rounder'));

  // Check minimum requirements
  if (wicketKeepers.total < rules.minWicketKeepers) {
    errors.push(`Need ${rules.minWicketKeepers} wicket keepers, have ${wicketKeepers.total}`);
  }

  if (bowlers.total < rules.minBowlers) {
    errors.push(`Need ${rules.minBowlers} bowlers, have ${bowlers.total}`);
  }

  if (batsmen.total < rules.minBatsmen) {
    errors.push(`Need ${rules.minBatsmen} batsmen, have ${batsmen.total}`);
  }

  if (allRounders.total < rules.minAllRounders) {
    errors.push(`Need ${rules.minAllRounders} all-rounders, have ${allRounders.total}`);
  }

  // Check tier limits
  if (batsmen.tierA > rules.maxTierABatsmen) {
    errors.push(`Maximum ${rules.maxTierABatsmen} Tier A batsmen allowed`);
  }

  if (batsmen.tierB > rules.maxTierBBatsmen) {
    errors.push(`Maximum ${rules.maxTierBBatsmen} Tier B batsmen allowed`);
  }

  if (bowlers.tierA > rules.maxTierABowlers) {
    errors.push(`Maximum ${rules.maxTierABowlers} Tier A bowlers allowed`);
  }

  if (bowlers.tierB > rules.maxTierBBowlers) {
    errors.push(`Maximum ${rules.maxTierBBowlers} Tier B bowlers allowed`);
  }

  if (allRounders.tierA > rules.maxTierAAllRounders) {
    errors.push(`Maximum ${rules.maxTierAAllRounders} Tier A all-rounders allowed`);
  }

  if (allRounders.tierB > rules.maxTierBAllRounders) {
    errors.push(`Maximum ${rules.maxTierBAllRounders} Tier B all-rounders allowed`);
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

function groupPlayersByTier(players: Player[]) {
  const tierA = players.filter(p => p.tier === 'A').length;
  const tierB = players.filter(p => p.tier === 'B').length;
  return {
    tierA,
    tierB,
    total: tierA + tierB
  };
}

export function getBestCaptainCandidates(players: Player[], count: number = 3): Player[] {
  return players
    .filter(p => p.leadership && p.leadership > 60)
    .sort((a, b) => (b.leadership || 0) - (a.leadership || 0))
    .slice(0, count);
}