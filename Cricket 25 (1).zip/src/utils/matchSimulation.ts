import { Player, Team } from '../types/game';

interface MatchResult {
  winner: Team;
  loser: Team;
  winnerScore: number;
  loserScore: number;
  playerPerformances: PlayerPerformance[];
}

interface PlayerPerformance {
  playerId: string;
  runs?: number;
  wickets?: number;
  catches?: number;
}

interface TeamStrength {
  battingStrength: number;
  bowlingStrength: number;
  totalStrength: number;
}

const calculateTeamStrength = (team: Team): TeamStrength => {
  const players = team.players;
  
  const battingStrength = players.reduce((sum, player) => {
    const battingContribution = player.batting * (player.form / 100);
    return sum + battingContribution;
  }, 0) / players.length;

  const bowlingStrength = players.reduce((sum, player) => {
    const bowlingContribution = player.bowling * (player.form / 100);
    return sum + bowlingContribution;
  }, 0) / players.length;

  return {
    battingStrength,
    bowlingStrength,
    totalStrength: (battingStrength + bowlingStrength) / 2
  };
};

const generatePlayerPerformance = (
  player: Player,
  teamStrength: TeamStrength,
  oppositionStrength: TeamStrength
): PlayerPerformance => {
  const performanceMultiplier = (teamStrength.totalStrength / oppositionStrength.totalStrength);
  const formFactor = player.form / 100;

  const performance: PlayerPerformance = {
    playerId: player.id
  };

  // Generate batting performance
  if (player.role === 'Batsman' || player.role === 'All-rounder' || player.role === 'Wicket Keeper') {
    const baseRuns = Math.floor(
      (player.batting * formFactor * performanceMultiplier * Math.random()) / 2
    );
    performance.runs = Math.min(baseRuns, 200); // Cap at 200 runs
  }

  // Generate bowling performance
  if (player.role === 'Bowler' || player.role === 'All-rounder') {
    const baseWickets = Math.floor(
      (player.bowling * formFactor * performanceMultiplier * Math.random()) / 20
    );
    performance.wickets = Math.min(baseWickets, 10); // Cap at 10 wickets
  }

  // Generate fielding performance
  const catchProbability = player.fielding / 200;
  if (Math.random() < catchProbability) {
    performance.catches = Math.floor(Math.random() * 3); // 0-2 catches
  }

  return performance;
};

export const simulateMatch = (teamA: Team, teamB: Team): MatchResult => {
  const teamAStrength = calculateTeamStrength(teamA);
  const teamBStrength = calculateTeamStrength(teamB);

  // Calculate scores based on team strengths
  const baseScore = 250;
  const teamAScore = Math.floor(
    baseScore * (teamAStrength.battingStrength / teamBStrength.bowlingStrength) * 
    (0.8 + Math.random() * 0.4)
  );
  const teamBScore = Math.floor(
    baseScore * (teamBStrength.battingStrength / teamAStrength.bowlingStrength) * 
    (0.8 + Math.random() * 0.4)
  );

  // Generate player performances
  const performances: PlayerPerformance[] = [
    ...teamA.players.map(player => 
      generatePlayerPerformance(player, teamAStrength, teamBStrength)
    ),
    ...teamB.players.map(player => 
      generatePlayerPerformance(player, teamBStrength, teamAStrength)
    )
  ];

  // Determine winner
  const winner = teamAScore > teamBScore ? teamA : teamB;
  const loser = teamAScore > teamBScore ? teamB : teamA;
  const winnerScore = Math.max(teamAScore, teamBScore);
  const loserScore = Math.min(teamAScore, teamBScore);

  return {
    winner,
    loser,
    winnerScore,
    loserScore,
    playerPerformances: performances
  };
};

export const updatePlayerStatsPostMatch = (
  player: Player,
  performance: PlayerPerformance
): Player => {
  let formChange = 0;
  let experienceGain = 10;

  if (performance.runs) {
    formChange += performance.runs > 50 ? 5 : -2;
    experienceGain += performance.runs > 50 ? 5 : 0;
  }

  if (performance.wickets) {
    formChange += performance.wickets > 2 ? 5 : -2;
    experienceGain += performance.wickets > 2 ? 5 : 0;
  }

  return {
    ...player,
    form: Math.max(0, Math.min(100, player.form + formChange)),
    experience: player.experience + experienceGain
  };
};