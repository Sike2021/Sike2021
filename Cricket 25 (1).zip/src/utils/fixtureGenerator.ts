import { Match, Team, Ground, Format } from '../types/game';
import { v4 as uuidv4 } from 'uuid';

const FORMATS: Format[] = ['T20', 'ODI', 'Test'];

export function generateInitialFixtures(teams: Team[], grounds: Ground[]): Match[] {
  const matches: Match[] = [];
  let matchDay = 1;

  // Generate round-robin fixtures
  for (let i = 0; i < teams.length; i++) {
    for (let j = i + 1; j < teams.length; j++) {
      // Create matches for each format
      FORMATS.forEach((format) => {
        // Home match
        matches.push({
          id: uuidv4(),
          homeTeam: teams[i],
          awayTeam: teams[j],
          date: new Date(Date.now() + matchDay * 24 * 60 * 60 * 1000), // Add days
          venue: grounds[Math.floor(Math.random() * grounds.length)],
          format,
          status: 'scheduled',
          matchDay
        });

        // Away match
        matches.push({
          id: uuidv4(),
          homeTeam: teams[j],
          awayTeam: teams[i],
          date: new Date(Date.now() + (matchDay + 1) * 24 * 60 * 60 * 1000),
          venue: grounds[Math.floor(Math.random() * grounds.length)],
          format,
          status: 'scheduled',
          matchDay: matchDay + 1
        });

        matchDay += 2;
      });
    }
  }

  return matches.sort((a, b) => a.date.getTime() - b.date.getTime());
}

export function generateNextSeasonFixtures(
  teams: Team[],
  grounds: Ground[],
  startDate: Date
): Match[] {
  const matches: Match[] = [];
  let matchDay = 1;

  for (let i = 0; i < teams.length; i++) {
    for (let j = i + 1; j < teams.length; j++) {
      FORMATS.forEach((format) => {
        matches.push({
          id: uuidv4(),
          homeTeam: teams[i],
          awayTeam: teams[j],
          date: new Date(startDate.getTime() + matchDay * 24 * 60 * 60 * 1000),
          venue: grounds[Math.floor(Math.random() * grounds.length)],
          format,
          status: 'scheduled',
          matchDay
        });

        matches.push({
          id: uuidv4(),
          homeTeam: teams[j],
          awayTeam: teams[i],
          date: new Date(startDate.getTime() + (matchDay + 1) * 24 * 60 * 60 * 1000),
          venue: grounds[Math.floor(Math.random() * grounds.length)],
          format,
          status: 'scheduled',
          matchDay: matchDay + 1
        });

        matchDay += 2;
      });
    }
  }

  return matches.sort((a, b) => a.date.getTime() - b.date.getTime());
}