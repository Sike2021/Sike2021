import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { TeamOverview } from './components/TeamOverview';
import { MainMenu } from './components/MainMenu';
import { GameRecords } from './components/GameRecords';
import { TeamEditor } from './components/TeamEditor';
import { GameSettings } from './components/GameSettings';
import { AuctionSystem } from './components/AuctionSystem';
import { FixturesView } from './components/FixturesView';
import { initialGameState } from './data/initialGameState';
import { Player, Match } from './types/game';
import { simulateMatch, updatePlayerStatsPostMatch } from './utils/matchSimulation';
import './index.css';

function App() {
  const [gameState, setGameState] = useState(initialGameState);
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);

  const handleTrainPlayer = (playerId: string) => {
    setGameState(prev => {
      const updatedPlayers = prev.team.players.map(player => {
        if (player.id === playerId) {
          return {
            ...player,
            batting: Math.min(100, player.batting + 2),
            bowling: Math.min(100, player.bowling + 2),
            experience: player.experience + 10,
            form: Math.max(0, player.form - 5)
          };
        }
        return player;
      });

      return {
        ...prev,
        funds: prev.funds - 10000,
        team: { ...prev.team, players: updatedPlayers }
      };
    });
  };

  const handleRestPlayer = (playerId: string) => {
    setGameState(prev => {
      const updatedPlayers = prev.team.players.map(player => {
        if (player.id === playerId) {
          return {
            ...player,
            form: Math.min(100, player.form + 15)
          };
        }
        return player;
      });

      return {
        ...prev,
        funds: prev.funds - 5000,
        team: { ...prev.team, players: updatedPlayers }
      };
    });
  };

  const handlePlayerPurchase = (player: Player, amount: number) => {
    setGameState(prev => ({
      ...prev,
      funds: prev.funds - amount,
      team: {
        ...prev.team,
        players: [...prev.team.players, player]
      }
    }));
  };

  const handlePlayMatch = (match: Match) => {
    const result = simulateMatch(match.homeTeam, match.awayTeam);
    
    // Update match status and result
    setGameState(prev => ({
      ...prev,
      matches: prev.matches.map(m => {
        if (m.id === match.id) {
          return {
            ...m,
            status: 'completed',
            result
          };
        }
        return m;
      })
    }));

    // Update player stats based on performances
    if (match.homeTeam.id === gameState.team.id || match.awayTeam.id === gameState.team.id) {
      setGameState(prev => {
        const updatedPlayers = prev.team.players.map(player => {
          const performance = result.playerPerformances.find(p => p.playerId === player.id);
          if (performance) {
            return updatePlayerStatsPostMatch(player, performance);
          }
          return player;
        });

        return {
          ...prev,
          team: { ...prev.team, players: updatedPlayers }
        };
      });
    }
  };

  const handleExitGame = () => {
    if (window.confirm('Are you sure you want to exit the game? All unsaved progress will be lost.')) {
      window.close();
    }
  };

  return (
    <Router>
      <div className="flex min-h-screen bg-gray-50">
        <Sidebar funds={gameState.funds} onExit={handleExitGame} />
        
        <div className="flex-1">
          <Routes>
            <Route path="/" element={<Navigate to="/menu" replace />} />
            
            <Route path="/menu" element={
              <MainMenu gameState={gameState} />
            } />
            
            <Route path="/team" element={
              <TeamOverview
                team={gameState.team}
                onPlayerSelect={setSelectedPlayer}
                selectedPlayer={selectedPlayer}
                onTrainPlayer={handleTrainPlayer}
                onRestPlayer={handleRestPlayer}
              />
            } />
            
            <Route path="/fixtures" element={
              <FixturesView
                gameState={gameState}
                onPlayMatch={handlePlayMatch}
              />
            } />
            
            <Route path="/records" element={
              <GameRecords gameState={gameState} />
            } />
            
            <Route path="/editor" element={
              <TeamEditor 
                gameState={gameState}
                onUpdateGame={setGameState}
              />
            } />
            
            <Route path="/settings" element={
              <GameSettings
                gameState={gameState}
                onUpdateGame={setGameState}
              />
            } />

            <Route path="/auction" element={
              <AuctionSystem
                playerPool={[
                  ...gameState.playerPool.batsmen,
                  ...gameState.playerPool.bowlers,
                  ...gameState.playerPool.allRounders,
                  ...gameState.playerPool.wicketKeepers
                ].filter(p => p.available)}
                currentFunds={gameState.funds}
                onPlayerPurchased={handlePlayerPurchase}
                onAuctionComplete={() => setGameState(prev => ({
                  ...prev,
                  season: prev.season + 1
                }))}
              />
            } />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;