import { Team, Player } from '../types/game';
import { PlayerCard } from './PlayerCard';
import { PlayerDetailsModal } from './PlayerDetailsModal';
import { Users, AlertCircle } from 'lucide-react';

interface TeamOverviewProps {
  team: Team;
  selectedPlayer: Player | null;
  onPlayerSelect: (player: Player | null) => void;
  onTrainPlayer: (playerId: string) => void;
  onRestPlayer: (playerId: string) => void;
}

export function TeamOverview({ 
  team, 
  selectedPlayer, 
  onPlayerSelect,
  onTrainPlayer,
  onRestPlayer
}: TeamOverviewProps) {
  const squadCount = team.players.length;
  const remainingSlots = team.maxSquadSize - squadCount;

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Users className="w-8 h-8 text-blue-600" />
          <h2 className="text-2xl font-bold">{team.name}</h2>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-600">Squad: {squadCount}/{team.maxSquadSize}</span>
          {remainingSlots > 0 && (
            <div className="flex items-center gap-1 text-amber-600">
              <AlertCircle className="w-4 h-4" />
              <span className="text-sm">{remainingSlots} slots available</span>
            </div>
          )}
        </div>
      </div>
      
      {squadCount === 0 ? (
        <div className="text-center py-8">
          <p className="text-gray-500">No players in squad. Wait for the auction to build your team.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {team.players.map((player) => (
            <PlayerCard 
              key={player.id} 
              player={player}
              onClick={() => onPlayerSelect(player)}
            />
          ))}
        </div>
      )}

      {selectedPlayer && (
        <PlayerDetailsModal
          player={selectedPlayer}
          isOpen={!!selectedPlayer}
          onClose={() => onPlayerSelect(null)}
          onTrain={onTrainPlayer}
          onRest={onRestPlayer}
        />
      )}
    </div>
  );
}