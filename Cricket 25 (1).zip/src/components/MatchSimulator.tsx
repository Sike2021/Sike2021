import { useState } from 'react';
import { Team } from '../types/game';
import { simulateMatch } from '../utils/matchSimulation';
import { Trophy, Clock, Target } from 'lucide-react';

interface MatchSimulatorProps {
  teamA: Team;
  teamB: Team;
  onMatchComplete: (
    winner: Team,
    loser: Team,
    winnerScore: number,
    loserScore: number
  ) => void;
}

export function MatchSimulator({ teamA, teamB, onMatchComplete }: MatchSimulatorProps) {
  const [isSimulating, setIsSimulating] = useState(false);
  const [matchResult, setMatchResult] = useState<ReturnType<typeof simulateMatch> | null>(null);

  const handleSimulate = () => {
    setIsSimulating(true);
    setTimeout(() => {
      const result = simulateMatch(teamA, teamB);
      setMatchResult(result);
      onMatchComplete(
        result.winner,
        result.loser,
        result.winnerScore,
        result.loserScore
      );
      setIsSimulating(false);
    }, 2000); // Artificial delay for drama
  };

  if (matchResult) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-6 max-w-2xl mx-auto">
        <div className="text-center mb-6">
          <Trophy className="w-12 h-12 text-yellow-500 mx-auto mb-2" />
          <h2 className="text-2xl font-bold text-gray-900">Match Complete</h2>
        </div>

        <div className="grid grid-cols-3 gap-4 items-center mb-6">
          <div className="text-right">
            <h3 className="font-semibold">{matchResult.winner.name}</h3>
            <p className="text-2xl font-bold text-green-600">
              {matchResult.winnerScore}
            </p>
          </div>
          <div className="text-center text-gray-500">vs</div>
          <div className="text-left">
            <h3 className="font-semibold">{matchResult.loser.name}</h3>
            <p className="text-2xl font-bold text-red-600">
              {matchResult.loserScore}
            </p>
          </div>
        </div>

        <div className="space-y-4">
          {matchResult.playerPerformances
            .filter(p => p.runs || p.wickets)
            .slice(0, 5)
            .map((perf, idx) => {
              const player = [...teamA.players, ...teamB.players]
                .find(p => p.id === perf.playerId);
              if (!player) return null;

              return (
                <div 
                  key={perf.playerId}
                  className="flex justify-between items-center p-3 bg-gray-50 rounded-lg"
                >
                  <span className="font-medium">{player.name}</span>
                  <div className="space-x-4">
                    {perf.runs && (
                      <span className="text-green-600">{perf.runs} runs</span>
                    )}
                    {perf.wickets && (
                      <span className="text-blue-600">{perf.wickets} wickets</span>
                    )}
                  </div>
                </div>
              );
            })}
        </div>
      </div>
    );
  }

  return (
    <div className="text-center p-6">
      <button
        onClick={handleSimulate}
        disabled={isSimulating}
        className={`
          px-6 py-3 rounded-lg text-white font-semibold
          ${isSimulating 
            ? 'bg-gray-400 cursor-not-allowed' 
            : 'bg-blue-600 hover:bg-blue-700'
          }
        `}
      >
        {isSimulating ? (
          <span className="flex items-center gap-2">
            <Clock className="w-5 h-5 animate-spin" />
            Simulating...
          </span>
        ) : (
          <span className="flex items-center gap-2">
            <Target className="w-5 h-5" />
            Start Match
          </span>
        )}
      </button>
    </div>
  );
}