import { Player } from '../types/game';
import { PlayerCard } from './PlayerCard';
import { Tab } from '@headlessui/react';
import { Users, Shield, Cricket, Star } from 'lucide-react';

interface PlayerPoolViewProps {
  playerPool: {
    batsmen: Player[];
    bowlers: Player[];
    wicketKeepers: Player[];
    allRounders: Player[];
  };
  onPlayerSelect: (player: Player) => void;
}

export function PlayerPoolView({ playerPool, onPlayerSelect }: PlayerPoolViewProps) {
  const categories = [
    { name: 'Batsmen', icon: Shield, players: playerPool.batsmen },
    { name: 'Bowlers', icon: Cricket, players: playerPool.bowlers },
    { name: 'Wicket Keepers', icon: Star, players: playerPool.wicketKeepers },
    { name: 'All-Rounders', icon: Users, players: playerPool.allRounders },
  ];

  return (
    <div className="w-full px-2 py-6">
      <Tab.Group>
        <Tab.List className="flex space-x-1 rounded-xl bg-blue-900/20 p-1">
          {categories.map((category) => (
            <Tab
              key={category.name}
              className={({ selected }) =>
                `w-full rounded-lg py-2.5 text-sm font-medium leading-5
                 ${selected
                  ? 'bg-white text-blue-700 shadow'
                  : 'text-blue-100 hover:bg-white/[0.12] hover:text-white'
                }`
              }
            >
              <div className="flex items-center justify-center gap-2">
                <category.icon className="w-4 h-4" />
                <span>{category.name}</span>
                <span className="bg-blue-100 text-blue-700 rounded-full px-2">
                  {category.players.length}
                </span>
              </div>
            </Tab>
          ))}
        </Tab.List>
        <Tab.Panels className="mt-2">
          {categories.map((category, idx) => (
            <Tab.Panel
              key={idx}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4"
            >
              {category.players.map((player) => (
                <PlayerCard
                  key={player.id}
                  player={player}
                  onClick={() => onPlayerSelect(player)}
                />
              ))}
            </Tab.Panel>
          ))}
        </Tab.Panels>
      </Tab.Group>
    </div>
  );
}