import { useState } from 'react';
import { GameState, Player } from '../types/game';
import { Edit2, Save, X } from 'lucide-react';

interface TeamEditorProps {
  gameState: GameState;
  onUpdateGame: (newState: GameState) => void;
}

export function TeamEditor({ gameState, onUpdateGame }: TeamEditorProps) {
  const [editingPlayer, setEditingPlayer] = useState<Player | null>(null);
  const [editForm, setEditForm] = useState<Partial<Player>>({});

  const handleEditPlayer = (player: Player) => {
    setEditingPlayer(player);
    setEditForm(player);
  };

  const handleSavePlayer = () => {
    if (!editingPlayer || !editForm) return;

    const updatedPlayers = gameState.team.players.map(player =>
      player.id === editingPlayer.id ? { ...player, ...editForm } : player
    );

    onUpdateGame({
      ...gameState,
      team: { ...gameState.team, players: updatedPlayers }
    });

    setEditingPlayer(null);
    setEditForm({});
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Team Editor</h1>
        <p className="text-gray-600 mt-2">Modify player attributes and team settings</p>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-gray-50">
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-600">Name</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-600">Role</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-600">Batting</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-600">Bowling</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-600">Form</th>
              <th className="px-6 py-3 text-right text-sm font-semibold text-gray-600">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {gameState.team.players.map(player => (
              <tr key={player.id}>
                {editingPlayer?.id === player.id ? (
                  <>
                    <td className="px-6 py-4">
                      <input
                        type="text"
                        value={editForm.name || ''}
                        onChange={e => setEditForm({ ...editForm, name: e.target.value })}
                        className="border rounded px-2 py-1 w-full"
                      />
                    </td>
                    <td className="px-6 py-4">
                      <select
                        value={editForm.role || player.role}
                        onChange={e => setEditForm({ ...editForm, role: e.target.value as Player['role'] })}
                        className="border rounded px-2 py-1"
                      >
                        <option value="Batsman">Batsman</option>
                        <option value="Bowler">Bowler</option>
                        <option value="All-rounder">All-rounder</option>
                        <option value="Wicket Keeper">Wicket Keeper</option>
                      </select>
                    </td>
                    <td className="px-6 py-4">
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={editForm.batting || 0}
                        onChange={e => setEditForm({ ...editForm, batting: Number(e.target.value) })}
                        className="border rounded px-2 py-1 w-20"
                      />
                    </td>
                    <td className="px-6 py-4">
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={editForm.bowling || 0}
                        onChange={e => setEditForm({ ...editForm, bowling: Number(e.target.value) })}
                        className="border rounded px-2 py-1 w-20"
                      />
                    </td>
                    <td className="px-6 py-4">
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={editForm.form || 0}
                        onChange={e => setEditForm({ ...editForm, form: Number(e.target.value) })}
                        className="border rounded px-2 py-1 w-20"
                      />
                    </td>
                    <td className="px-6 py-4 text-right space-x-2">
                      <button
                        onClick={handleSavePlayer}
                        className="text-green-600 hover:text-green-700"
                      >
                        <Save className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => setEditingPlayer(null)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </td>
                  </>
                ) : (
                  <>
                    <td className="px-6 py-4">{player.name}</td>
                    <td className="px-6 py-4">{player.role}</td>
                    <td className="px-6 py-4">{player.batting}</td>
                    <td className="px-6 py-4">{player.bowling}</td>
                    <td className="px-6 py-4">{player.form}</td>
                    <td className="px-6 py-4 text-right">
                      <button
                        onClick={() => handleEditPlayer(player)}
                        className="text-blue-600 hover:text-blue-700"
                      >
                        <Edit2 className="w-5 h-5" />
                      </button>
                    </td>
                  </>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}