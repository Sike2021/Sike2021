import { GameState } from '../types/game';
import { Save, RefreshCw } from 'lucide-react';

interface GameSettingsProps {
  gameState: GameState;
  onUpdateGame: (newState: GameState) => void;
}

export function GameSettings({ gameState, onUpdateGame }: GameSettingsProps) {
  const handleUpdateTeamName = (newName: string) => {
    onUpdateGame({
      ...gameState,
      team: { ...gameState.team, name: newName }
    });
  };

  const handleUpdateSquadSize = (newSize: number) => {
    onUpdateGame({
      ...gameState,
      team: { ...gameState.team, maxSquadSize: newSize }
    });
  };

  const handleResetGame = () => {
    if (window.confirm('Are you sure you want to reset the game? This cannot be undone.')) {
      localStorage.clear();
      window.location.reload();
    }
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Game Settings</h1>
        <p className="text-gray-600 mt-2">Configure your game parameters</p>
      </div>

      <div className="max-w-2xl space-y-6">
        <div className="bg-white p-6 rounded-xl border border-gray-200">
          <h2 className="text-lg font-semibold mb-4">Team Settings</h2>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Team Name
              </label>
              <input
                type="text"
                value={gameState.team.name}
                onChange={(e) => handleUpdateTeamName(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-4 py-2"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Maximum Squad Size
              </label>
              <input
                type="number"
                min="11"
                max="25"
                value={gameState.team.maxSquadSize}
                onChange={(e) => handleUpdateSquadSize(Number(e.target.value))}
                className="w-full border border-gray-300 rounded-lg px-4 py-2"
              />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-gray-200">
          <h2 className="text-lg font-semibold mb-4">Game Controls</h2>
          
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-medium">Save Game</h3>
                <p className="text-sm text-gray-500">Save your current progress</p>
              </div>
              <button
                onClick={() => {
                  localStorage.setItem('gameState', JSON.stringify(gameState));
                }}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <Save className="w-4 h-4" />
                Save
              </button>
            </div>

            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-medium">Reset Game</h3>
                <p className="text-sm text-gray-500">Start a new game from scratch</p>
              </div>
              <button
                onClick={handleResetGame}
                className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                <RefreshCw className="w-4 h-4" />
                Reset
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}