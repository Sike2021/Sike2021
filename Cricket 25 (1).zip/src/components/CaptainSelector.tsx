import { Player, Format, Captain } from '../types/game';
import { Crown } from 'lucide-react';

interface CaptainSelectorProps {
  player: Player;
  format: Format;
  currentCaptains: Captain[];
  onSelectCaptain: (playerId: string, format: Format) => void;
}

export function CaptainSelector({ 
  player, 
  format, 
  currentCaptains, 
  onSelectCaptain 
}: CaptainSelectorProps) {
  const isCaptain = currentCaptains.some(
    c => c.playerId === player.id && c.format === format
  );

  return (
    <button
      onClick={() => onSelectCaptain(player.id, format)}
      className={`flex items-center gap-2 px-3 py-1 rounded-full text-sm
        ${isCaptain 
          ? 'bg-amber-100 text-amber-700' 
          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
        }`}
    >
      <Crown className={`w-4 h-4 ${isCaptain ? 'text-amber-500' : 'text-gray-400'}`} />
      <span>{format}</span>
    </button>
  );
}