import { Player } from '../types/game';
import { Shield, Cricket, DollarSign } from 'lucide-react';

interface PlayerCardProps {
  player: Player;
  onClick?: () => void;
}

export function PlayerCard({ player, onClick }: PlayerCardProps) {
  return (
    <div 
      onClick={onClick}
      className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-gray-100"
    >
      <div className="flex items-center justify-between mb-2">
        <h3 className="font-semibold text-lg">{player.name}</h3>
        <span className="text-sm text-gray-500">Age: {player.age}</span>
      </div>
      
      <div className="text-sm text-gray-600 mb-2">{player.role}</div>
      
      <div className="grid grid-cols-2 gap-2">
        <div className="flex items-center gap-1">
          <Shield size={16} className="text-blue-500" />
          <span className="text-sm">Batting: {player.batting}</span>
        </div>
        <div className="flex items-center gap-1">
          <Cricket size={16} className="text-green-500" />
          <span className="text-sm">Bowling: {player.bowling}</span>
        </div>
      </div>
      
      <div className="mt-2 flex gap-2">
        <div className="text-xs px-2 py-1 bg-gray-100 rounded-full">
          Form: {player.form}/100
        </div>
        <div className="text-xs px-2 py-1 bg-gray-100 rounded-full">
          Exp: {player.experience}
        </div>
      </div>

      <div className="mt-2 flex items-center gap-1 text-green-600">
        <DollarSign size={14} />
        <span className="text-sm font-medium">${player.basePrice.toLocaleString()}</span>
        <span className="text-xs text-gray-500 ml-1">({player.contractYears} yr)</span>
      </div>
    </div>
  );
}