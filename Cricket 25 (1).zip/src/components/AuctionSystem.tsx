import { useState, useEffect } from 'react';
import { Player, PlayerTier, AuctionPool } from '../types/game';
import { DollarSign, Timer, Users, Star, Shield, AlertCircle } from 'lucide-react';

interface AuctionSystemProps {
  playerPool: AuctionPool;
  currentFunds: number;
  onPlayerPurchased: (player: Player, amount: number) => void;
  onAuctionComplete: () => void;
}

type CategoryKey = 'batsmen' | 'spinBowlers' | 'fastBowlers' | 'allRounders' | 'wicketKeepers';
type TierKey = 'tierA' | 'tierB';

export function AuctionSystem({ 
  playerPool, 
  currentFunds, 
  onPlayerPurchased, 
  onAuctionComplete 
}: AuctionSystemProps) {
  const [currentCategory, setCurrentCategory] = useState<CategoryKey>('batsmen');
  const [currentTier, setCurrentTier] = useState<TierKey>('tierA');
  const [currentPlayers, setCurrentPlayers] = useState<Player[]>([]);
  const [bids, setBids] = useState<Record<string, number>>({});
  const [timeLeft, setTimeLeft] = useState(30);
  const [round, setRound] = useState(1);
  const [isRoundActive, setIsRoundActive] = useState(false);

  const CATEGORY_ORDER: CategoryKey[] = [
    'batsmen',
    'spinBowlers',
    'fastBowlers',
    'allRounders',
    'wicketKeepers'
  ];

  useEffect(() => {
    if (isRoundActive && timeLeft > 0) {
      const timer = setInterval(() => setTimeLeft(t => t - 1), 1000);
      return () => clearInterval(timer);
    } else if (timeLeft === 0 && currentPlayers.length > 0) {
      handleRoundComplete();
    }
  }, [timeLeft, isRoundActive]);

  const getNextCategory = (): { category: CategoryKey; tier: TierKey } | null => {
    const currentCategoryIndex = CATEGORY_ORDER.indexOf(currentCategory);
    
    if (currentTier === 'tierA') {
      return { category: currentCategory, tier: 'tierB' };
    }
    
    if (currentCategoryIndex < CATEGORY_ORDER.length - 1) {
      return { 
        category: CATEGORY_ORDER[currentCategoryIndex + 1],
        tier: 'tierA'
      };
    }

    return null;
  };

  const startNewRound = () => {
    const availablePlayers = playerPool[currentCategory][currentTier]
      .filter(p => p.available);

    if (availablePlayers.length === 0) {
      const next = getNextCategory();
      if (next) {
        setCurrentCategory(next.category);
        setCurrentTier(next.tier);
        setRound(r => r + 1);
        return;
      } else {
        onAuctionComplete();
        return;
      }
    }

    // Get next 4 players (or less if fewer available)
    const nextPlayers = availablePlayers.slice(0, 4);
    setCurrentPlayers(nextPlayers);
    
    // Initialize bids
    const initialBids = nextPlayers.reduce((acc, player) => {
      acc[player.id] = player.basePrice;
      return acc;
    }, {} as Record<string, number>);
    setBids(initialBids);
    
    setTimeLeft(30);
    setIsRoundActive(true);
  };

  const handleBid = (playerId: string, increment: number) => {
    const newBidAmount = (bids[playerId] || 0) + increment;
    if (newBidAmount > currentFunds) return;
    
    setBids(prev => ({
      ...prev,
      [playerId]: newBidAmount
    }));
    setTimeLeft(15); // Reset timer on new bid
  };

  const handleRoundComplete = () => {
    // Process successful bids
    currentPlayers.forEach(player => {
      const finalBid = bids[player.id];
      if (finalBid > player.basePrice) {
        onPlayerPurchased(player, finalBid);
        
        // Mark player as unavailable in the pool
        playerPool[currentCategory][currentTier] = playerPool[currentCategory][currentTier]
          .map(p => p.id === player.id ? { ...p, available: false } : p);
      }
    });

    setCurrentPlayers([]);
    setBids({});
    setIsRoundActive(false);
  };

  const getCategoryDisplay = (category: CategoryKey): string => {
    switch (category) {
      case 'batsmen': return 'Batsmen';
      case 'spinBowlers': return 'Spin Bowlers';
      case 'fastBowlers': return 'Fast Bowlers';
      case 'allRounders': return 'All-Rounders';
      case 'wicketKeepers': return 'Wicket Keepers';
    }
  };

  if (!isRoundActive) {
    const remainingPlayers = playerPool[currentCategory][currentTier]
      .filter(p => p.available).length;

    return (
      <div className="flex flex-col items-center justify-center h-96">
        <div className="text-center mb-6">
          <div className="text-sm font-medium text-blue-600 mb-2">
            {currentTier === 'tierA' ? 'Tier A' : 'Tier B'}
          </div>
          <h2 className="text-2xl font-bold mb-2">
            {getCategoryDisplay(currentCategory)} Auction
          </h2>
          <p className="text-gray-600">
            {remainingPlayers} players remaining
          </p>
        </div>
        <button
          onClick={startNewRound}
          className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Start Next Round
        </button>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <div className="text-sm font-medium text-blue-600">
            {currentTier === 'tierA' ? 'Tier A' : 'Tier B'}
          </div>
          <h2 className="text-2xl font-bold">
            {getCategoryDisplay(currentCategory)} Auction
          </h2>
        </div>
        <div className="flex items-center gap-4">
          <div className="bg-blue-50 px-4 py-2 rounded-lg">
            <Timer className="w-5 h-5 text-blue-600 inline mr-2" />
            <span className="font-semibold text-blue-700">{timeLeft}s</span>
          </div>
          <div className="bg-green-50 px-4 py-2 rounded-lg">
            <DollarSign className="w-5 h-5 text-green-600 inline mr-2" />
            <span className="font-semibold text-green-700">
              ${currentFunds.toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {currentPlayers.map(player => (
          <div key={player.id} className="bg-white rounded-xl shadow-lg p-4">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-bold text-lg">{player.name}</h3>
                <p className="text-gray-600">{player.role}</p>
              </div>
              <div className="flex items-center gap-1">
                <Star className={`w-5 h-5 ${
                  player.tier === 'A' ? 'text-yellow-500' : 'text-gray-400'
                }`} />
                <span className="text-sm font-medium">
                  Tier {player.tier}
                </span>
              </div>
            </div>

            <div className="space-y-3 mb-4">
              {player.attributes.battingAverage && (
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Batting Avg</span>
                  <span className="font-medium">{player.attributes.battingAverage}</span>
                </div>
              )}
              {player.attributes.strikeRate && (
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Strike Rate</span>
                  <span className="font-medium">{player.attributes.strikeRate}</span>
                </div>
              )}
              {player.attributes.economyRate && (
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Economy</span>
                  <span className="font-medium">{player.attributes.economyRate}</span>
                </div>
              )}
              {player.attributes.wickets && (
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Wickets</span>
                  <span className="font-medium">{player.attributes.wickets}</span>
                </div>
              )}
            </div>

            <div className="text-center mb-4">
              <div className="text-sm text-gray-600">Current Bid</div>
              <div className="text-xl font-bold text-blue-600">
                ${(bids[player.id] || 0).toLocaleString()}
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => handleBid(player.id, 10000)}
                className="px-2 py-1 bg-blue-100 text-blue-700 rounded hover:bg-blue-200"
              >
                +10k
              </button>
              <button
                onClick={() => handleBid(player.id, 50000)}
                className="px-2 py-1 bg-blue-100 text-blue-700 rounded hover:bg-blue-200"
              >
                +50k
              </button>
              <button
                onClick={() => handleBid(player.id, 100000)}
                className="px-2 py-1 bg-blue-100 text-blue-700 rounded hover:bg-blue-200"
              >
                +100k
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}