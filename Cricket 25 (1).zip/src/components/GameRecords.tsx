import { Trophy, Star, Users, TrendingUp } from 'lucide-react';
import { GameState } from '../types/game';

interface GameRecordsProps {
  gameState: GameState;
}

export function GameRecords({ gameState }: GameRecordsProps) {
  const topPlayers = gameState.team.players
    .sort((a, b) => (b.batting + b.bowling) - (a.batting + a.bowling))
    .slice(0, 5);

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Game Records</h1>
        <p className="text-gray-600 mt-2">Track your team's achievements and statistics</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl border border-gray-200">
          <div className="flex items-center gap-3 mb-4">
            <Trophy className="w-6 h-6 text-amber-500" />
            <h2 className="text-xl font-semibold">Top Players</h2>
          </div>
          <div className="space-y-4">
            {topPlayers.map((player, index) => (
              <div key={player.id} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                    {index + 1}
                  </div>
                  <div>
                    <div className="font-medium">{player.name}</div>
                    <div className="text-sm text-gray-500">{player.role}</div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-sm">
                    <div>BAT: {player.batting}</div>
                    <div>BOWL: {player.bowling}</div>
                  </div>
                  <Star className={`w-5 h-5 ${index === 0 ? 'text-yellow-400' : 'text-gray-300'}`} />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-gray-200">
          <div className="flex items-center gap-3 mb-4">
            <Users className="w-6 h-6 text-blue-500" />
            <h2 className="text-xl font-semibold">Team Statistics</h2>
          </div>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Total Players</span>
              <span className="font-semibold">{gameState.team.players.length}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Average Batting</span>
              <span className="font-semibold">
                {Math.round(gameState.team.players.reduce((acc, p) => acc + p.batting, 0) / 
                  Math.max(1, gameState.team.players.length))}
              </span>
            </div>
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Average Bowling</span>
              <span className="font-semibold">
                {Math.round(gameState.team.players.reduce((acc, p) => acc + p.bowling, 0) / 
                  Math.max(1, gameState.team.players.length))}
              </span>
            </div>
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Total Budget</span>
              <span className="font-semibold">${gameState.funds.toLocaleString()}</span>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-gray-200">
          <div className="flex items-center gap-3 mb-4">
            <TrendingUp className="w-6 h-6 text-green-500" />
            <h2 className="text-xl font-semibold">Season Progress</h2>
          </div>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Current Season</span>
              <span className="font-semibold">{gameState.season}</span>
            </div>
            {/* Add more season-specific stats here */}
          </div>
        </div>
      </div>
    </div>
  );
}