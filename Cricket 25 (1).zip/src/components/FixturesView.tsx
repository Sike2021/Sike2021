import { useState } from 'react';
import { Match, Format, GameState } from '../types/game';
import { CalendarDays, Clock, MapPin, Trophy } from 'lucide-react';
import { format } from 'date-fns';

interface FixturesViewProps {
  gameState: GameState;
  onPlayMatch: (match: Match) => void;
}

export function FixturesView({ gameState, onPlayMatch }: FixturesViewProps) {
  const [selectedFormat, setSelectedFormat] = useState<Format>('T20');
  
  const matches = gameState.matches || [];
  const filteredMatches = matches.filter(match => match.format === selectedFormat);
  
  const formatTabs: Format[] = ['T20', 'ODI', 'Test'];

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Fixtures & Results</h1>
        <p className="text-gray-600 mt-2">View upcoming matches and past results</p>
      </div>

      {/* Format selector */}
      <div className="flex space-x-1 rounded-xl bg-gray-100 p-1 mb-6 max-w-md">
        {formatTabs.map((format) => (
          <button
            key={format}
            onClick={() => setSelectedFormat(format)}
            className={`
              flex-1 py-2 px-4 rounded-lg text-sm font-medium
              ${selectedFormat === format
                ? 'bg-white text-blue-700 shadow'
                : 'text-gray-700 hover:bg-gray-200'
              }
            `}
          >
            {format}
          </button>
        ))}
      </div>

      {/* Fixtures list */}
      <div className="space-y-4">
        {filteredMatches.map((match) => (
          <div 
            key={match.id}
            className="bg-white rounded-lg shadow-sm border border-gray-200 p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 text-gray-500">
                <CalendarDays className="w-4 h-4" />
                <span>{format(new Date(match.date), 'MMM d, yyyy')}</span>
                <Clock className="w-4 h-4 ml-4" />
                <span>{format(new Date(match.date), 'h:mm a')}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-500">
                <MapPin className="w-4 h-4" />
                <span>{match.venue.name}</span>
              </div>
            </div>

            <div className="grid grid-cols-3 items-center gap-4">
              <div className="text-right">
                <h3 className="font-semibold text-lg">{match.homeTeam.name}</h3>
                {match.status === 'completed' && match.result && (
                  <p className={`text-sm ${
                    match.result.winner.id === match.homeTeam.id
                      ? 'text-green-600'
                      : 'text-red-600'
                  }`}>
                    {match.result.winner.id === match.homeTeam.id
                      ? match.result.winnerScore
                      : match.result.loserScore
                    }
                  </p>
                )}
              </div>

              <div className="text-center">
                {match.status === 'completed' ? (
                  <Trophy className="w-6 h-6 mx-auto text-amber-500" />
                ) : (
                  <span className="text-gray-400">vs</span>
                )}
              </div>

              <div className="text-left">
                <h3 className="font-semibold text-lg">{match.awayTeam.name}</h3>
                {match.status === 'completed' && match.result && (
                  <p className={`text-sm ${
                    match.result.winner.id === match.awayTeam.id
                      ? 'text-green-600'
                      : 'text-red-600'
                  }`}>
                    {match.result.winner.id === match.awayTeam.id
                      ? match.result.winnerScore
                      : match.result.loserScore
                    }
                  </p>
                )}
              </div>
            </div>

            {match.status === 'scheduled' && (
              <div className="mt-4 text-center">
                <button
                  onClick={() => onPlayMatch(match)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Play Match
                </button>
              </div>
            )}
          </div>
        ))}

        {filteredMatches.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            No {selectedFormat} matches scheduled
          </div>
        )}
      </div>
    </div>
  );
}