import { useNavigate } from 'react-router-dom';
import { Users, Award, Settings, Edit, PlayCircle } from 'lucide-react';
import { GameState } from '../types/game';

interface MainMenuProps {
  gameState: GameState;
}

export function MainMenu({ gameState }: MainMenuProps) {
  const navigate = useNavigate();

  const menuItems = [
    {
      icon: PlayCircle,
      title: 'Continue Game',
      description: 'Return to your team management',
      path: '/team',
      highlight: true,
    },
    {
      icon: Users,
      title: 'Team Overview',
      description: `Manage your ${gameState.team.players.length} players`,
      path: '/team',
    },
    {
      icon: Award,
      title: 'Game Records',
      description: 'View achievements and statistics',
      path: '/records',
    },
    {
      icon: Edit,
      title: 'Team Editor',
      description: 'Customize teams and players',
      path: '/editor',
    },
    {
      icon: Settings,
      title: 'Game Settings',
      description: 'Configure game parameters',
      path: '/settings',
    },
  ];

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Welcome Back</h1>
        <p className="text-gray-600 mt-2">
          Season {gameState.season} - {gameState.team.name}
        </p>
      </div>

      <div className="grid gap-4">
        {menuItems.map((item) => (
          <button
            key={item.path}
            onClick={() => navigate(item.path)}
            className={`
              w-full text-left p-6 rounded-xl transition-all
              ${item.highlight 
                ? 'bg-blue-600 hover:bg-blue-700 text-white'
                : 'bg-white hover:shadow-md border border-gray-200'
              }
            `}
          >
            <div className="flex items-start gap-4">
              <item.icon className={`w-6 h-6 ${item.highlight ? 'text-white' : 'text-gray-600'}`} />
              <div>
                <h2 className={`text-lg font-semibold ${item.highlight ? 'text-white' : 'text-gray-900'}`}>
                  {item.title}
                </h2>
                <p className={`mt-1 ${item.highlight ? 'text-blue-100' : 'text-gray-600'}`}>
                  {item.description}
                </p>
              </div>
            </div>
          </button>
        ))}
      </div>

      <div className="mt-8 p-4 bg-gray-50 rounded-lg">
        <h3 className="font-semibold text-gray-700">Quick Stats</h3>
        <div className="mt-2 grid grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-lg">
            <div className="text-sm text-gray-600">Team Funds</div>
            <div className="text-lg font-semibold">${gameState.funds.toLocaleString()}</div>
          </div>
          <div className="bg-white p-4 rounded-lg">
            <div className="text-sm text-gray-600">Squad Size</div>
            <div className="text-lg font-semibold">{gameState.team.players.length}/{gameState.team.maxSquadSize}</div>
          </div>
          <div className="bg-white p-4 rounded-lg">
            <div className="text-sm text-gray-600">Season</div>
            <div className="text-lg font-semibold">{gameState.season}</div>
          </div>
        </div>
      </div>
    </div>
  );
}