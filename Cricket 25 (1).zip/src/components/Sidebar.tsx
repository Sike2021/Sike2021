import { Link, useLocation } from 'react-router-dom';
import { 
  Home,
  Users,
  Award,
  Settings,
  Edit,
  LogOut,
  DollarSign,
  CalendarDays
} from 'lucide-react';

interface SidebarProps {
  funds: number;
  onExit: () => void;
}

export function Sidebar({ funds, onExit }: SidebarProps) {
  const location = useLocation();
  
  const menuItems = [
    { path: '/menu', icon: Home, label: 'Main Menu' },
    { path: '/team', icon: Users, label: 'Team' },
    { path: '/fixtures', icon: CalendarDays, label: 'Fixtures' },
    { path: '/records', icon: Award, label: 'Records' },
    { path: '/editor', icon: Edit, label: 'Editor' },
    { path: '/settings', icon: Settings, label: 'Settings' },
  ];

  return (
    <div className="w-64 bg-white border-r border-gray-200 p-4 flex flex-col h-screen">
      <div className="mb-8">
        <h1 className="text-xl font-bold text-gray-800">Cricket Pro Manager</h1>
      </div>

      <div className="flex-1">
        <nav className="space-y-2">
          {menuItems.map(({ path, icon: Icon, label }) => (
            <Link
              key={path}
              to={path}
              className={`flex items-center gap-3 px-4 py-2 rounded-lg transition-colors
                ${location.pathname === path
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-gray-600 hover:bg-gray-50'
                }`}
            >
              <Icon className="w-5 h-5" />
              <span>{label}</span>
            </Link>
          ))}
        </nav>
      </div>

      <div className="space-y-4">
        <div className="flex items-center gap-2 bg-green-50 px-4 py-2 rounded-lg">
          <DollarSign className="w-5 h-5 text-green-600" />
          <span className="font-semibold text-green-700">
            ${funds.toLocaleString()}
          </span>
        </div>

        <button
          onClick={onExit}
          className="w-full flex items-center gap-3 px-4 py-2 rounded-lg text-red-600 hover:bg-red-50 transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span>Exit Game</span>
        </button>
      </div>
    </div>
  );
}