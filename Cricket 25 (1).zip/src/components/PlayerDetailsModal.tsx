import { Dialog } from '@headlessui/react';
import { Shield, Cricket, Award, Activity, X, Crown } from 'lucide-react';
import { Player, Format, Captain } from '../types/game';
import { CaptainSelector } from './CaptainSelector';

interface PlayerDetailsModalProps {
  player: Player;
  isOpen: boolean;
  onClose: () => void;
  onTrain: (playerId: string) => void;
  onRest: (playerId: string) => void;
  onSelectCaptain?: (playerId: string, format: Format) => void;
  currentCaptains?: Captain[];
}

export function PlayerDetailsModal({ 
  player, 
  isOpen, 
  onClose, 
  onTrain, 
  onRest,
  onSelectCaptain,
  currentCaptains = []
}: PlayerDetailsModalProps) {
  const formats: Format[] = ['Test', 'ODI', 'T20'];

  return (
    <Dialog open={isOpen} onClose={onClose} className="relative z-50">
      <div className="fixed inset-0 bg-black/30" aria-hidden="true" />
      
      <div className="fixed inset-0 flex items-center justify-center p-4">
        <Dialog.Panel className="bg-white rounded-lg max-w-md w-full p-6">
          <div className="flex justify-between items-start mb-4">
            <Dialog.Title className="text-xl font-bold">{player.name}</Dialog.Title>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
              <X size={20} />
            </button>
          </div>

          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Stats</h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-blue-500" />
                  <span>Batting: {player.batting}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Cricket className="w-5 h-5 text-green-500" />
                  <span>Bowling: {player.bowling}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-yellow-500" />
                  <span>Experience: {player.experience}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-red-500" />
                  <span>Form: {player.form}/100</span>
                </div>
                {player.leadership && (
                  <div className="flex items-center gap-2 col-span-2">
                    <Crown className="w-5 h-5 text-amber-500" />
                    <span>Leadership: {player.leadership}</span>
                  </div>
                )}
              </div>
            </div>

            {onSelectCaptain && player.leadership && player.leadership > 60 && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-semibold mb-2">Captaincy</h3>
                <div className="flex gap-2">
                  {formats.map(format => (
                    <CaptainSelector
                      key={format}
                      player={player}
                      format={format}
                      currentCaptains={currentCaptains}
                      onSelectCaptain={onSelectCaptain}
                    />
                  ))}
                </div>
              </div>
            )}

            <div className="flex gap-3">
              <button
                onClick={() => onTrain(player.id)}
                className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Train Player
              </button>
              <button
                onClick={() => onRest(player.id)}
                className="flex-1 bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 transition-colors"
              >
                Rest Player
              </button>
            </div>
          </div>
        </Dialog.Panel>
      </div>
    </Dialog>
  );
}