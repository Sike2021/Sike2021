import { DollarSign } from 'lucide-react';

interface HeaderProps {
  funds: number;
}

export function Header({ funds }: HeaderProps) {
  return (
    <header className="bg-white border-b border-gray-200 px-6 py-4">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-800">Cricket Pro Manager</h1>
        <div className="flex items-center gap-2 bg-green-50 px-4 py-2 rounded-lg">
          <DollarSign className="w-5 h-5 text-green-600" />
          <span className="font-semibold text-green-700">
            ${funds.toLocaleString()}
          </span>
        </div>
      </div>
    </header>
  );
}