import { Team } from '../types/game';

export const teams: Team[] = [
  {
    id: 'keenjhur',
    name: 'Keenjhur Warriors',
    players: [], // Start with empty squad
    maxSquadSize: 15
  },
  {
    id: 'east',
    name: 'Eastern Strikers',
    players: [], // Start with empty squad
    maxSquadSize: 15
  },
  {
    id: 'west',
    name: 'Western Dolphins',
    players: [], // Start with empty squad
    maxSquadSize: 15
  },
  {
    id: 'north',
    name: 'Northern Stars',
    players: [], // Start with empty squad
    maxSquadSize: 15
  },
  {
    id: 'south',
    name: 'Southern Knights',
    players: [], // Start with empty squad
    maxSquadSize: 15
  },
  {
    id: 'central',
    name: 'Central County',
    players: [], // Start with empty squad
    maxSquadSize: 15
  }
];