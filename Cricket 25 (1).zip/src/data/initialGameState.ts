import { GameState } from '../types/game';
import { generateBalancedPlayerPool } from '../utils/playerGenerator';
import { grounds } from './grounds';
import { teams } from './teams';
import { generateInitialFixtures } from '../utils/fixtureGenerator';

const initialPlayerPool = generateBalancedPlayerPool();

// Create initial fixtures between all teams
const initialFixtures = generateInitialFixtures(teams, grounds);

export const initialGameState: GameState = {
  team: {
    id: '1',
    name: 'Your Team',
    players: [],
    maxSquadSize: 15,
    captains: []
  },
  funds: 5000000,
  season: 1,
  playerPool: initialPlayerPool,
  matches: initialFixtures
};