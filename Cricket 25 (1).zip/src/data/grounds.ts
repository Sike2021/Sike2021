export interface Ground {
  id: string;
  name: string;
  capacity: number;
  location: string;
}

export const grounds: Ground[] = [
  {
    id: 'central',
    name: 'Central Cricket Ground',
    capacity: 35000,
    location: 'Central District'
  },
  {
    id: 'eastern',
    name: 'Eastern Club Cricket Ground',
    capacity: 28000,
    location: 'Eastern District'
  },
  {
    id: 'western',
    name: 'Western Stadium',
    capacity: 30000,
    location: 'Western District'
  },
  {
    id: 'northern',
    name: 'Northern Cricket Complex',
    capacity: 25000,
    location: 'Northern District'
  },
  {
    id: 'southern',
    name: 'Southern Cricket Arena',
    capacity: 32000,
    location: 'Southern District'
  },
  {
    id: 'county',
    name: 'County Cricket Ground',
    capacity: 40000,
    location: 'County Center'
  }
];